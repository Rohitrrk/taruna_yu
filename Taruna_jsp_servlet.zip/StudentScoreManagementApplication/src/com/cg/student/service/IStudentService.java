package com.cg.student.service;

import java.util.ArrayList;

import com.cg.student.bean.StudentDetailsBean;


public interface IStudentService {

	public ArrayList<StudentDetailsBean> getDetails();
	public int addStudentDetails(StudentDetailsBean bean);
}
