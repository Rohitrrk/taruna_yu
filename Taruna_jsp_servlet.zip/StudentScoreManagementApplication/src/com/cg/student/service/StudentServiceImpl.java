package com.cg.student.service;

import java.util.ArrayList;




import com.cg.student.bean.StudentDetailsBean;
import com.cg.student.dao.IStudentDao;
import com.cg.student.dao.StudentDaoImpl;

public class StudentServiceImpl implements IStudentService {

	IStudentDao dao= new StudentDaoImpl();
	public ArrayList<StudentDetailsBean> getDetails() {
		return dao.getDetails();
	}
	
	public int addStudentDetails(StudentDetailsBean bean)
	{
		return dao.addStudentDetails(bean);
	}

}
