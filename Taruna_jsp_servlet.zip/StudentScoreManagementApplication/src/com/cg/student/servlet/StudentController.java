package com.cg.student.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.cg.student.bean.StudentDetailsBean;
import com.cg.student.service.IStudentService;
import com.cg.student.service.StudentServiceImpl;



@WebServlet("*.obj")
public class StudentController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out= response.getWriter();
		StudentDetailsBean bean= new StudentDetailsBean();
		IStudentService service=new StudentServiceImpl();
		String path=request.getServletPath();
		System.out.println(path);
		String target = null;
		int res=0;
		int flag=0;
		
		switch(path)
		{
			case "/retrieve.obj":
				
				target="StudentScores.jsp";
				
				break;
			
			case "/newStudent.obj":
				
				target="NewStudent.jsp";
				break;
				
			case "/addDetails.obj":
			{
				String studentId=request.getParameter("sid");
				String name=request.getParameter("name");
				String sAge=request.getParameter("age");
				String state=request.getParameter("state");
				String gender=request.getParameter("gender");
				String centum1 = request.getParameter("centum");
				String attempts= request.getParameter("attempts");
				String score=request.getParameter("total");
				int sid=Integer.parseInt(studentId);
				int Age=Integer.parseInt(sAge);
				int centum=Integer.parseInt(centum1);
				int attempt=Integer.parseInt(attempts);
				int totalScore=Integer.parseInt(score);
				bean.setStudent_id(sid);
				bean.setStudentName(name);
				bean.setStudentAge(Age);
				bean.setCountry(state);
				bean.setGender(gender);
				bean.setCentum(centum);
				bean.setAttemptNo(attempt);
				bean.setTotalScore(totalScore);
				res=service.addStudentDetails(bean);
				System.out.println(res);
				if(res>0)
					target="InsertSuccess.jsp";
				else
					target="Error.jsp";
				break;
				
			}	
			
		}
		RequestDispatcher rd= request.getRequestDispatcher(target);
		rd.forward(request, response);
		
	}

	

}
