package com.cg.student.bean;

public class StudentDetailsBean {
	
	private int student_id;
	private String studentName;
	private int studentAge;
	private String country;
	private String gender;
	private int centum;
	private int attemptNo;
	private int totalScore;
	
	
	
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getStudentAge() {
		return studentAge;
	}
	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getCentum() {
		return centum;
	}
	public void setCentum(int centum) {
		this.centum = centum;
	}
	public int getAttemptNo() {
		return attemptNo;
	}
	public void setAttemptNo(int attemptNo) {
		this.attemptNo = attemptNo;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	
	
	
	@Override
	public String toString() {
		return "StudentDetailsBean [student_id=" + student_id
				+ ", studentName=" + studentName + ", studentAge=" + studentAge
				+ ", country=" + country + ", gender=" + gender + ", centum="
				+ centum + ", attemptNo=" + attemptNo + ", totalScore="
				+ totalScore + "]";
	}
	
	
	
	
	
	public StudentDetailsBean(String studentName, int studentAge,
			String country, String gender, int centum, int attemptNo,
			int totalScore) {
		super();
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.country = country;
		this.gender = gender;
		this.centum = centum;
		this.attemptNo = attemptNo;
		this.totalScore = totalScore;
	}
	public StudentDetailsBean() {
		// TODO Auto-generated constructor stub
	}
	public StudentDetailsBean(int student_id, String studentName,
			int studentAge, String country, String gender, int centum,
			int attemptNo, int totalScore) {
		super();
		this.student_id = student_id;
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.country = country;
		this.gender = gender;
		this.centum = centum;
		this.attemptNo = attemptNo;
		this.totalScore = totalScore;
	}
	
	

}
