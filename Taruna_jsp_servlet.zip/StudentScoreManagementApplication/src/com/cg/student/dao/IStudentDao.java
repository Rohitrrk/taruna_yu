package com.cg.student.dao;

import java.util.ArrayList;

import com.cg.student.bean.StudentDetailsBean;

public interface IStudentDao {

	ArrayList<StudentDetailsBean> getDetails();

	int addStudentDetails(StudentDetailsBean bean);

}
