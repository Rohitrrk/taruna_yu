package com.cg.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;





import com.cg.student.bean.StudentDetailsBean;
import com.cg.student.dbutil.DbUtil;

public class StudentDaoImpl implements IStudentDao {

	
	public ArrayList<StudentDetailsBean> getDetails() 
	{
		ArrayList<StudentDetailsBean> list=new ArrayList<StudentDetailsBean>();
		Connection con=DbUtil.getConnection();
		try {
			String sql="select * from Student_score";
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int age=rs.getInt(3);
				String state=rs.getString(4);
				String gender=rs.getString(5);
				int centum=rs.getInt(6);
				int attempts=rs.getInt(6);
				int totalScore=rs.getInt(6);
				
				list.add(new StudentDetailsBean(id,name,age,state,gender,centum,attempts,totalScore));
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		
		return list;
		
	}

	@Override
	public int addStudentDetails(StudentDetailsBean bean) {
		Connection conn=null;
		int row = 0;
		int value = 0;
		try
		{
			conn=DbUtil.getConnection();
			PreparedStatement ps=conn.prepareStatement("insert into Student_score values(student_id.nextval,?,?,?,?,?,?,?)");
			

			ps.setString(1, bean.getStudentName());
			ps.setInt(2, bean.getStudentAge());
			ps.setString(3, bean.getCountry());
			ps.setString(4, bean.getGender());
			ps.setInt(5, bean.getCentum());
			ps.setInt(6, bean.getAttemptNo());
			ps.setInt(7, bean.getTotalScore());
			row=ps.executeUpdate();
	
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		return row;
		
	}

}
